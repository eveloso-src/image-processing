/**
 * 
 * $Id: GrabberThreadTest.java,v 1.1.1.1 2002/08/06 02:35:44 pete Exp $
 * @author $Author: pete $
 * @version $Revision: 1.1.1.1 $
 * 
 * TestCase for the GrabberThread.
 */

package org.petecode.jgrabber;

import java.net.URL;
import java.util.Random;

import org.apache.log4j.BasicConfigurator;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class GrabberThreadTest extends TestCase {

	private URL testURL1;
	private URL testURL2;

	public GrabberThreadTest(String test){
		super(test);	
	}

	protected void setUp() throws Exception{
		testURL1 = new URL("http://216.234.118.40/webcams/gwynns_1.jpg");
		testURL2 = new URL("http://216.234.118.40/webcams/gwynns_2.jpg");
		BasicConfigurator.configure();
		
	}

	public void testGrabberThread() throws Exception{
		GrabberThread gt1 = new GrabberThread("gwynns1", "webcams\\", testURL1, 1000, 5, 10000);
		GrabberThread gt2 = new GrabberThread("gwynns2", "webcams\\", testURL2, 1000, 5, 10000);
		gt1.start();
		gt2.start();
		while(true){
			Thread.yield();
		}
	}


	public static Test suite() {
    	return new TestSuite(GrabberThreadTest.class);
	}
	
	public static void main(String args[]) {
        junit.textui.TestRunner.run(suite());
    }
	
} 


