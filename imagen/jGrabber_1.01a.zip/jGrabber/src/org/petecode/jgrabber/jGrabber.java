/**
 * 
 * $Id: jGrabber.java,v 1.3 2002/08/06 14:00:13 pete Exp $
 * @author $Author: pete $
 * @version $Revision: 1.3 $
 * 
 */
package org.petecode.jgrabber;

import java.io.File;
import java.net.URL;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Appender;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;


/**
 * jGrabber is a command-line webcam image capture utility. It reads in configuration
 * information from an xml file and lauches GrabberThreads to capture each wevcam url.
 * 
 */
public class jGrabber {

	
	/**
	 *  Main method. Starts jGrabber
	 */
	public static void main (String args[]){
		String configFileName = "jgrabber.xml";
	
		
  if (args.length != 0) configFileName = args[0];
		File configFile = new File(configFileName);
		
		try{
			//Parse xml file for runtime options
			DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder domBuilder =  domFactory.newDocumentBuilder();
			Document dom = domBuilder.parse(configFile);
			Element jgrabber = dom.getDocumentElement();
	
			//Set up logger
			Element debugElement = (Element)jgrabber.getElementsByTagName("debug").item(0);
			Level debugLevel = Level.toLevel(debugElement.getAttribute("level"));
			String logfile = debugElement.getAttribute("logfile");

			PatternLayout pl = new PatternLayout("%-5p [%t]: %m%n");
			if (debugLevel.equals(Level.DEBUG)){
				pl = new PatternLayout("%-5p [%t]: %d%l%m%n");
			}
			
			Appender myFileAppender = new FileAppender(pl, logfile);
			BasicConfigurator.configure(myFileAppender);
			Logger.getRootLogger().setLevel(debugLevel);
		
			//Start GrabberThreads
			String rootdir = jgrabber.getAttribute("rootdir");
			Element webcams = (Element)jgrabber.getElementsByTagName("webcams").item(0);
			NodeList camList = webcams.getElementsByTagName("cam");

	
			GrabberThread[] gt = new GrabberThread[camList.getLength()];
			for (int i=0; i < camList.getLength(); i++){
				Element webcamElement = (Element)camList.item(i);
				String username = webcamElement.getAttribute("username");
				if (username.length() > 0) {
					//No USERNAME/PASSWORD specified
					gt[i] = new GrabberThread(webcamElement.getAttribute("name"),
											  rootdir,
											  new URL(webcamElement.getAttribute("url")),
											  webcamElement.getAttribute("username"),
											  webcamElement.getAttribute("password"),
											  Integer.parseInt(webcamElement.getAttribute("reload")),
											  Integer.parseInt(webcamElement.getAttribute("sleepThreshold")),
											  Integer.parseInt(webcamElement.getAttribute("sleepTime")));
				} else{
					//USERNAME/PASSWORD specified
					gt[i] = new GrabberThread(webcamElement.getAttribute("name"),
											  rootdir,
											  new URL(webcamElement.getAttribute("url")),
											  Integer.parseInt(webcamElement.getAttribute("reload")),
											  Integer.parseInt(webcamElement.getAttribute("sleepThreshold")),
											  Integer.parseInt(webcamElement.getAttribute("sleepTime")));
				}
				gt[i].start();
			}			 
			
			//Keep this application running while the threads execute
			while (true){
				Thread.sleep(1000);
			}		
	
		} catch (Throwable t){
			t.printStackTrace();	
			System.exit(1);
		}	

	}

}
