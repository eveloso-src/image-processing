/**
 * 
 * $Id: GrabberThread.java,v 1.4 2002/08/12 12:08:09 pete Exp $
 * @author $Author: pete $
 * @version $Revision: 1.4 $
 * 
 */


package org.petecode.jgrabber;

import java.io.File;
import java.io.FileOutputStream;
import java.io.DataInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import org.apache.log4j.Logger;
import sun.misc.BASE64Encoder;

/**
 * The GrabberThread object is a single thread that is responsible for 
 * downloading a webcam image at a predetermined interval.
 */

public class GrabberThread extends Thread{

	private String imageName = null;
	private String imageDir = null;
	private String username = null;
	private String password = null;
	private URL webcamURL = null;
	private int sleepThreshold = 0; //Number of duplicate images needed to 
	                                 //sleep the thread
	private int reloadTime = 0; //Time in ms to wait before reloading the 
	                             //image
	private int sleepTime = 0; //Time in ms to sleep if duplicate images 
	                            //are downloaded
	
	private Logger logger;
	private byte[] lastImage = null;
	private int sleepCount = 0;	
	private Random random = new Random();
	
	private boolean keepRunning = true; //Flag indicating whether the run method should keep looping

	

	/**
	 * Constructs the thread
     * @param imageName the name of the image. This is used as the prefix of the filename.
	 * @param imageDir the directory where the image will be saved
	 * @param webcamURL the url of the webcam image being downloaded
	 * @param reloadTime the time, in ms, that will elapse between each image
	 * being downloaded
	 * @param sleepThreshold the number of duplicate images that will be
	 * downloaded before putting this thread to sleep.
	 * @param sleepTime the time, in ms, that the thread will sleep for if the
	 * sleep threshold is reached
	 */
	public GrabberThread(String imageName, String imageDir, URL webcamURL, int reloadTime, int sleepThreshold, int sleepTime){
		this.imageName = imageName;
		this.imageDir = imageDir;
		 
		this.webcamURL = webcamURL;
		this.reloadTime = reloadTime;
		this.sleepThreshold = sleepThreshold;
		this.sleepTime = sleepTime;	
		this.logger = Logger.getLogger(this.getClass());
		logger.info("Instantiating GrabberThread for " + imageName + ": " + webcamURL);
	}

	/**
	 * Constructs the thread
	 * @param webcamURL the url of the webcam image being downloaded
	 * @param reloadTime the time, in ms, that will elapse between each image being
	 * downloaded
	 * @param sleepThreshold the number of duplicate images that will be downloaded before
	 * putting this thread to sleep.
	 * @param sleepTime the time, in ms, that the thread will sleep for if the sleep
	 * threshold is reached
	 */
	public GrabberThread(String imageName, String imageDir, URL webcamURL, String username, String password, int reloadTime, int sleepThreshold, int sleepTime){
		this(imageName, imageDir, webcamURL, reloadTime, sleepThreshold, sleepTime);
		this.username = username;
		this.password = password;
	}
	


	/**
	 * Starts the grabber thread.
	 */ 
	public void start(){
		keepRunning = true;	
		logger.info("Starting thread for " + imageName);
		super.start();
	}

	/**
	 * Causes the thread loop to terminate, thus killing the thread. This method
	 * has been added since stop was made final and depreciated in jdk1.4
	 */
	public void stopRunning(){
        keepRunning = false;
    }

	/**
	 * Returns true if a username/password has been specified for this URL. Otherwise, false.
	 * @return true if a username/password has been specified for this URL. Otherwise, false.
	 */
	public boolean isPasswordProtected(){
		return (username != null);	
	}


	/**
	 * This method overrides Thread.run. Its function is to poll the URL at a 
	 * predetermined interval so that the image can be downloaded
	 */
	
	public void run() {
		logger.info("Running for " + imageName);
		//Makse sure the directory structure exists
		File rootDirectory = new File(imageDir);
		rootDirectory.mkdirs();
		File webcamDirectory = new File(rootDirectory, imageName);
		webcamDirectory.mkdirs();

       	while (keepRunning) {
			logger.debug("Running for " + imageName);
			HttpURLConnection httpConn = getConnection();
			byte[] image = downloadImage(httpConn);
			int sleepInterval = reloadTime;
			//Create the directory
			if (image.length <= 0) {
				logger.info(imageName + " - Broken/Bad Image ");
				if (sleepThreshold != 0) sleepCount ++;
			} else if (isDifferent(lastImage, image)){
				File imgFile = new File(webcamDirectory, getFileName(httpConn.getContentType()));
				saveFile(imgFile, image);					
				lastImage = image;
				sleepCount = 0;
			} else {
				if (logger.isInfoEnabled()) logger.info(imageName + " - Duplicate file encountered.");
				if (sleepThreshold != 0) sleepCount ++;
				//Check to see if the sleep threshold has been met. if so, change the reload time
				//to the sleepTime.
			}
			if (sleepCount >= sleepThreshold){
				logger.info(imageName + " - Sleep threshold reached. Sleeping for " + sleepTime + " ms");
				sleepInterval = sleepTime;
				logger.debug(imageName + " - Reset sleep counter.");
				sleepCount = 0;
			}

			httpConn.disconnect();
			//Sleep until the image is to be downloaded again.					
			try {
           	  	sleep(sleepInterval);
			} catch (InterruptedException ie){
           		logger.warn(imageName + " - InterruptedException Caught", ie);
           	}
		}
    }
    
    /**
     * Saves the file to disk
     */
    protected boolean saveFile(File  imgFile, byte[] image){
		if (logger.isInfoEnabled()) logger.info("Saving webcam file " + imgFile);
    	try{
			FileOutputStream fos = new FileOutputStream(imgFile);
			fos.write(image);
			fos.close();
    		return true;
    	} catch (Exception ex){
    		logger.error("Exception caught while saving file", ex);
    		return false;	
    	}	
    }

	/**
	 *  This method makes the HTTP connection to the web server. If a username/password
	 * has been supplied, it is sent using Basic Authorization.
	 * @return the HttpURLConnection for the given webcam image
	 */
	protected HttpURLConnection getConnection(){
		logger.info(imageName + " - getting HTTP Connection to " + webcamURL);
		try{
			HttpURLConnection httpConn =(HttpURLConnection) webcamURL.openConnection();
			httpConn.setUseCaches(false);	
			if (isPasswordProtected()){
        	    String authString = username + ":" + password;
        	    BASE64Encoder encoder = new BASE64Encoder();
    	        String encoded = encoder.encode(authString.getBytes());
				if (logger.isDebugEnabled()) logger.debug("Sending Auth String: " + authString + "|" + encoded);
				if (logger.isDebugEnabled()) logger.debug("SetReqiestProperty: "+ "Basic " + encoded);
				httpConn.setRequestProperty("Authorization", "Basic " + encoded);
			}
			return httpConn;
		} catch (Exception ex){
			logger.error("Exception caught while establishing the HTTP Connection", ex);
			return null;	
		}
	}

	/**
	 * Downloads the image from the specified URL and saves it to disk.
	 * @return the byte array of the image
	 */ 
	protected byte[] downloadImage(HttpURLConnection httpConn){
		logger.debug("downloading image: " + webcamURL);
		
		try{
			int fileLength = httpConn.getContentLength();
			if (logger.isDebugEnabled()) logger.debug("File is " + fileLength + " bytes");
			byte[] fileBytes;
		
			//Read the file from the stream
			if (fileLength > 0){
				//If we know the file length, its a simple read
				fileBytes = new byte[fileLength];
				DataInputStream dis = new DataInputStream(httpConn.getInputStream());
				dis.readFully(fileBytes);
				dis.close();
			} else{
				//If we don't know the file length, we need to keep hitting the stream
				//until the end of the stream is encountered.
				
				if (logger.isDebugEnabled()) logger.debug("Downloading image of unknown size for " + imageName);
				InputStream is = httpConn.getInputStream();
				byte[] tempBytes = new byte[1000000];
				boolean keepReading = true;
				fileLength = 0;
				while (keepReading){
					int byteLength = is.read(tempBytes, fileLength, tempBytes.length - fileLength);
					if (byteLength == -1) {
						keepReading = false;	
					} else {
						if (logger.isDebugEnabled()) logger.debug("downloaded " + byteLength + " bytes for " + imageName);
						fileLength = fileLength + byteLength;
					}					
				}
				fileBytes = new byte[fileLength];
				if (logger.isDebugEnabled()) logger.debug("Unknown Image size is " + fileLength + " bytes for " + imageName);
				for (int i=0; i < fileLength; i++){
					fileBytes[i] = tempBytes[i];
				}
			}

			httpConn.disconnect();
			return fileBytes;			
		} catch (Exception ex){
			logger.error("Exception caught while downloading image.", ex);
			return null;		
		}
	}

    	
	/**
	 * Returns the filename that will be used to save the image. The filename consists of
	 * the directory, the image name, and the timestamp of the image.
	 * @return a string filename of the image that is being saved.
     */
	private String getFileName(String contentType){
		String extension = getExtension(contentType);
		Date myDate = new Date();
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
		String fileName = imageName + "_" + df.format(myDate) + getExtension(contentType);
		if (logger.isDebugEnabled()) logger.debug("File Name is " + fileName);
		return fileName;
	}
	

	/**
	 * Returns the extension for the specified content type. The default content type 
	 * is jpg.
	 */	
	private String getExtension(String contentType){
		if ((contentType != null) && (contentType.indexOf("gif") > 0)) return ".gif";
		return ".jpg";
	}


	/**
	 * Fast check to see if the files are different. The first check is to see if they
	 * are the same size. The second step is to check random bytes to see if they are
	 * the same. I chose to go with this algorithm over an MD5 signature because this
	 * was lighter in weight. 99.9% of the time, a different webcam image will be indicated
	 * w/ a different size. The random byte check allows for a double check.
	 */
	private boolean isDifferent(byte[] image1, byte[] image2){
		if ((image1 == null) || (image2 == null)) return true;

		//If the images are of different length then they are definately not the same.
		if (image1.length != image2.length) return true;
		
		//Check random bytes to see if they are the same. If any of these bytes are
		for (int i=0; i < 5; i++){
			int byteNum = random.nextInt(image1.length);
			if (image1[byteNum] != image2[byteNum]) return true;
		}		
		return false;			
	}		
}
